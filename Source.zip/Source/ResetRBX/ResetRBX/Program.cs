﻿using System;
using System.Net;
using System.IO;
using System.Diagnostics;


namespace Reset_rbx
{
    class Program
    {
        static void Main(string[] args)
        {
            ServicePointManager.Expect100Continue = true; //shit pasted from stackoverflow so it wouldn't error while trying to download roblox from the offical website
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; //shit pasted from stackoverflow so it wouldn't error while trying to download roblox from the offical website
            String appdata = Environment.ExpandEnvironmentVariables("%appdata%");
            string Desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            String localappdata = Environment.ExpandEnvironmentVariables("%localappdata%");
            Console.Title = "Reset RBX";
            File.Copy(localappdata + @"\\Roblox\\GlobalBasicSettings_13.xml", appdata + @"\\GlobalBasicSettings_13.xml");
            Console.WriteLine("Settings copied to appdata");
            Directory.Delete(localappdata + "\\Roblox", true);
            Console.Clear();
            Console.WriteLine("Settings copied to appdata");
            Console.WriteLine("Deleted Roblox Folder in Local appdata");
            Console.Clear();
            Console.WriteLine("Settings copied to appdata");
            Console.WriteLine("Deleted Roblox Folder in Local appdata");
            Console.WriteLine("Deleting game visit history");
            System.Diagnostics.Process.Start("CMD.exe", "/C del %APPDATA%\\..\\LocalLow\\rbxcsettings.rbx"); //For some reason File.Delete didn't work so had to use a cmd command
            Console.Clear();
            Console.WriteLine("Settings copied to appdata");
            Console.WriteLine("Deleted Roblox Folder in Local appdata");
            Console.WriteLine("Deleting game visit history");
            Console.WriteLine("Downloading Robloxsetup to temp");
            Console.Beep(400, 500); //funni sound
            WebClient webClient = new WebClient();
            string environmentVariable = Environment.GetEnvironmentVariable("temp");
            webClient.DownloadFile("https://www.roblox.com/download/client", environmentVariable + "/rbxsetup.exe");
            Console.Clear();
            Console.WriteLine("Settings copied to appdata");
            Console.WriteLine("Deleted Roblox Folder in Local appdata");
            Console.WriteLine("Deleting game visit history");
            Console.WriteLine("Downloading Robloxsetup to temp");
            Console.WriteLine("Executing Setup file");
            Process process = new Process();
            process.StartInfo.FileName = environmentVariable + "//rbxsetup.exe";
            process.StartInfo.WindowStyle = ProcessWindowStyle.Minimized;
            process.Start();
            Console.Beep(200, 500); //funni sound
            process.WaitForExit();
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            File.Delete(localappdata + "\\Roblox\\GlobalBasicSettings_13.xml");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            File.Copy(appdata + @"\\GlobalBasicSettings_13.xml", localappdata + @"\\Roblox\\GlobalBasicSettings_13.xml");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            Console.WriteLine("Deleting Setup file from temp");
            File.Delete(environmentVariable + "/rbxsetup.exe");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            Console.WriteLine("Deleting Setup file from temp");
            Console.WriteLine("Deleting Global settings from appdata");
            File.Delete(appdata + "\\GlobalBasicSettings_13.xml");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            Console.WriteLine("Deleting Setup file from temp");
            Console.WriteLine("Deleting Global settings from appdata");
            Console.WriteLine("Deleting shortcuts from desktop");
            File.Delete(Desktop + "\\Roblox Player.lnk");
            File.Delete(Desktop + "\\Roblox Studio.lnk");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            Console.WriteLine("Deleting Setup file from temp");
            Console.WriteLine("Deleting Global settings from appdata");
            Console.WriteLine("Deleting shortcuts from desktop");
            Console.Clear();
            Console.WriteLine("Deleting Global settings from new roblox install");
            Console.WriteLine("Restoring Global settings");
            Console.WriteLine("Deleting Setup file from temp");
            Console.WriteLine("Deleting Global settings from appdata");
            Console.WriteLine("Deleting shortcuts from desktop");
            Console.WriteLine("Clearing temp");
            System.Diagnostics.Process.Start("CMD.exe", "/C del / s / f / q %temp%\\*.* "); //CBA to find get C# to do it this was easier and does the same thing
            Console.WriteLine("Done, Games may take longer to load since they will need to be redownloaded");
            Console.Beep(200, 500); //funni sound
            Console.ReadLine();
        }
    }
}
